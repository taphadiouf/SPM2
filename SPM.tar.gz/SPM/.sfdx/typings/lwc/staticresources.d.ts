declare module "@salesforce/resourceUrl/GanttChart" {
    var GanttChart: string;
    export default GanttChart;
}
declare module "@salesforce/resourceUrl/GanttView" {
    var GanttView: string;
    export default GanttView;
}
declare module "@salesforce/resourceUrl/SPM_logo" {
    var SPM_logo: string;
    export default SPM_logo;
}
declare module "@salesforce/resourceUrl/SldsStatic" {
    var SldsStatic: string;
    export default SldsStatic;
}
declare module "@salesforce/resourceUrl/chartJs" {
    var chartJs: string;
    export default chartJs;
}
declare module "@salesforce/resourceUrl/chartJs2" {
    var chartJs2: string;
    export default chartJs2;
}
declare module "@salesforce/resourceUrl/expense" {
    var expense: string;
    export default expense;
}
declare module "@salesforce/resourceUrl/invoice" {
    var invoice: string;
    export default invoice;
}
declare module "@salesforce/resourceUrl/loader" {
    var loader: string;
    export default loader;
}
