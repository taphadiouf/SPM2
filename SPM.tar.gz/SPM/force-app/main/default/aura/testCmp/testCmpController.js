({

    doInit: function (component, event, helper) {
        var menu = [
            { label: 'Show details', name: 'show_details' },
            { label: 'Edit', name: 'edit' },
            { label: 'Delete', name: 'delete' },
            { label: 'Assign member', name: 'assignMember' },
        ];
        component.set('v.columns', [
            {label:'Project', fieldName:'AccountId', type:'text'},
            { label: 'Name', fieldName: 'Name', type: 'name' },
            {label:'Status', fieldName:'Status', type:'text'},
            {label:'Start Date', fieldName:'StartDate__c', type:'Date'},
            {label:'End Date', fieldName:'EndDate__c', type:'Date'}, 
            {label:'Link', fieldName:'Link__c', type:'text'},
           /*  {label:'Estimated Hours', fieldname:'Quantity', type:'number'},
            {label:'Billable Hours', fieldname:'AssetLevel', type:'number'},
            {label:'Logged Hours', fieldname:'Logged_Hours__c', type:'number'}, */
            // {label:'Description', fieldname:'Description', type:'text'},
            /* { label: 'Gender', fieldName: 'LeadSource', type: 'picklist' },
            { label: 'Contract Type', fieldName: 'Level__c', type: 'picklist' },
            { label: 'Organisation Unit', fieldName: 'organisation_Unit__r', type: 'text' },*/
            {
                type: 'action',
                typeAttributes: { rowActions: menu },
            } 
        ]);
        var pageSize = component.get("v.pageSize");
        var projectId = component.get("v.recordId");
        
        if(projectId === ''){
            helper.getTasks(component,pageSize);
        }else{
            helper.getTasksByProjectId(component,pageSize,projectId);
        }

    },

     handleRowAction: function (component, event, helper) {
        var value = event.getParam('value');
        var action =value.split('|')[0];
        var id = value.split('|')[1];
        switch (action) {
            case 'delete':
                alert('Delete');
                helper.deleteTask(component, id);
                break;
            case 'edit':
                helper.editTask(component, id);
            default:
        }
    },
               
    openModalNewTask:function(component,event,helper){
        component.set('v.isModal',true);
    },

    addTaskToList: function (component, event, helper) {
        var task = event.getParam('task');
        var numberOfTasksToDisplay = component.get('v.numberOfTasksToDisplay');
        var tasks = component.get('v.tasks');
        Tasks.unshift(task);
        numberOfTasksToDisplay.unshift(task);
        component.set('v.numberOfTasksToDisplay', numberOfTasksToDisplay);
        component.set('v.tasks', task);
    },

    

    displayTaskToListFiltered: function (component, event, helper) {
        console.log('event handle')
        var filter = event.getParam('filter'),
            tasks = component.get('v.tasks');
        var dataTemp = tasks.filter((task) => {
            return (
                task.Status.toLowerCase().includes(filter.status.toLowerCase()) &&
                task.Account.Id.toLowerCase().includes(filter.project.toLowerCase()) //&&
                /* task.ContactId.includes(filter.member) &&
                task.cost__c == filter.timeScale */
            )
        });
        console.log('After filter ' + dataTemp)
        component.set('v.tasksSelected', dataTemp);
        component.set("v.totalSize", component.get("v.tasksSelected").length);
        var numberOfTasksToDisplay = [];

        for (var i = 0; i < component.get("v.totalSize"); i++) {

            numberOfTasksToDisplay.push(component.get("v.tasksSelected")[i]);

        }
        component.set('v.numberOfTasksToDisplay', numberOfTasksToDisplay);
        
    },
    
     search : function(component, event, helper) {
        var searchValue = component.get("v.searchValue");
        if(searchValue === ""){
            helper.datasFilter(component);
        }
        else{
            helper.search(component, searchValue);
        }
     },
            
    selectedPage: function (component, event, helper) {
        helper.showSpinner(component);
        var selectedPageNumber = Number(event.getSource().get('v.name'));
        component.set("v.currentPageNumber", selectedPageNumber);
        helper.datasFilter(component);
    },
    nextPage: function (component, event, helper) {
        helper.showSpinner(component);
        var currentPageNumber = component.get("v.currentPageNumber");
        component.set("v.currentPageNumber", currentPageNumber+1);
        helper.datasFilter(component);
    },
    previousPage: function (component, event, helper) {
        helper.showSpinner(component);
        var currentPageNumber = component.get("v.currentPageNumber");
        component.set("v.currentPageNumber", currentPageNumber-1);
        helper.datasFilter(component);
    },
    showDetailsTask: function (component, event, helper) {
        var task = event.getParam('task');
        component.set('v.task',task);
        var target = event.currentTarget;
        //var taskId = component.get('v.taskId');
        console.log('task id ' + JSON.stringify(task));
        //helper.showRowDetails(component, event);
    },
    
    filter: function (component, event, helper) {
        if (component.get('v.showFilter')) {
            component.set('v.showFilter', false);
            component.set('v.size', 12);
        } else {
            helper.getAllStatus(component);
            helper.getAllProjects(component);
            helper.getAllMembers(component);
            
            component.set('v.showFilter', true);
            component.set('v.size', 10);
        }
    },

    applyFilter: function(component,event,helper){
       
        var pageSize = component.get("v.pageSize");
        helper.helperFunction(component, 0, pageSize);
    },

    refresh: function (component, event, helper) {
        $A.get('e.force:refreshView').fire();
    }
 
  
})