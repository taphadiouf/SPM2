({
    getProject: function (component, event, helper) {
        var recordId = component.get('v.recordId');
        var action = component.get("c.getProjectById");
        action.setParams({ id: recordId });
        action.setCallback(this, (response) => {
            var state = response.getState();
            if (state === "SUCCESS") {
                var customResponse = response.getReturnValue();
                if (customResponse.hasError == false) {
                    var project = customResponse.data;
                    if (project.hasOwnProperty('Contracts')) {
                        project.teamSize = project.Contracts.length;
                        project.Contracts.forEach(member => {
                            if (member.hasOwnProperty('Type__c')) {
                                if (member.Type__c === 'Project Management') {
                                    if (member.hasOwnProperty('SPM_Members__r')) {
                                        if (member.SPM_Members__r.hasOwnProperty('Name')) {
                                            project.projectManager = member.SPM_Members__r.Name;
                                            project.projectManagerId = member.SPM_Members__r.Id;
                                        }
                                    }
                                }
                            }
                        });
                    }
                    if (project.hasOwnProperty('Description')) {
                        project.Description = project.Description.replace(/(<([^>]+)>)/ig, "");
                    }
                    component.set('v.project', project);
                } else {
                    for (var message in customResponse.messages) {
                        console.log(message);
                    }
                }
            }
            else {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " +
                            errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(action);
    },

    showRowDetails: function (id) {
        var navEvt = $A.get("e.force:navigateToSObject");
        navEvt.setParams({
            "recordId": id,
            "slideDevName": "view"
        });
        navEvt.fire();

    },
})