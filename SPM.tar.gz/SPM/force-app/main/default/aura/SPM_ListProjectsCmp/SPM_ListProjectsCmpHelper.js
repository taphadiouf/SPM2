({

    deleteProjects: function (component, row) {
        var action = component.get("c.deleteProject");
        var project = { 'Id': row };
        action.setParams({ project: project });
        action.setCallback(this, function (response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var customResponse = response.getReturnValue();
                if (customResponse.hasError == false) {
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Success!",
                        "message": "The record has been deleted successfully.",
                        "type": "Success"
                    });
                    toastEvent.fire();
                    $A.get('e.force:refreshView').fire();
                } else {
                    for (var message in customResponse.messages) {
                        console.log(message);
                    }
                }
            }
            else {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " +
                            errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(action);

    },

    showRowDetails: function (component, event, projectId) {
        var navEvt = $A.get("e.force:navigateToSObject");
        navEvt.setParams({
            "recordId": projectId,
            "slideDevName": "related"
        });
        navEvt.fire();

    },

    editProject: function (component, row) {
        //var project = JSON.parse(JSON.stringify(row));
        component.set('v.isModalNewProject', true);
        component.set('v.recordId', row);
        var projects = component.get('v.projects');
        projects = projects.filter(project => project.Id === row);
        if(projects.length >=0){
            if (projects[0].hasOwnProperty('Contracts')) {
                    if (projects[0].Contracts[0].hasOwnProperty('Type__c')) {
                        if (projects[0].Contracts[0].Type__c === 'Project Management') {
                            if (projects[0].Contracts[0].hasOwnProperty('SPM_Members__c')) {
                               component.set('v.projectManagementId',projects[0].Contracts[0].SPM_Members__c);
                            }
                        }
                };
            }
            component.set('v.project', projects[0]);
        }
    },

    hideSpinner: function (component) {
        component.set("v.loading", false);
    },

    everyMinute: function (component) {
        var that = this;
        window.setTimeout(
            $A.getCallback(function () {
                var updated = component.get('v.updated');
                updated = updated + 1;
                component.set('v.updated', updated);
                var upadateHours = Math.floor(component.get('v.updated') / 60);
                component.set('v.updatedHours', upadateHours);
                that.everyMinute(component);
            }), 60000
        );

    },

    assignMembers: function (component, row) {
        var project = JSON.parse(JSON.stringify(row));
        component.set('v.isModal', true);
        component.set('v.recordId', project.Id);
        component.set('v.project', project);
    },

    allProject: function (component, pageSize) {
        var action = component.get("c.getAllProjects");

        action.setCallback(this, function (response) {

            var state = response.getState();

            if (component.isValid() && state === "SUCCESS") {
                var projects = response.getReturnValue().data;
                component.set('v.projects', projects);
                console.log('projects ' + JSON.stringify(response.getReturnValue().data));
                component.set("v.totalSize", component.get("v.projects").length);
                var numberOfPages = component.get("v.projects").length / component.get("v.pageSize");
                console.log('--------nombre de pages------------- ' + numberOfPages);
                var pages = [];
                for (var i = 0; i < numberOfPages; i++) {
                    if (i === 0) {
                        pages[i] = i;
                    } else {
                        pages[i] = Number(pages[i - 1]) + Number(component.get("v.pageSize"));
                    }
                }
                component.set("v.pages", pages);
                component.set("v.numberOfPages", pages[i - 1]);
                this.helperFunction(component, 0, component.get("v.pageSize"));
            }
            this.hideSpinner(component);

        });

        $A.enqueueAction(action);
    },

    helperFunction: function (component, dep, pageSize) {
        var searchKey = component.get("v.searchKey");
        var projects = component.get('v.projects');
        var filter = component.get('v.filter');
        var pageLenght = Number(dep) + Number(pageSize);
        if ($A.util.isEmpty(searchKey)) {
            if (component.get('v.showFilter')) {
                var dataTempo = projects.filter(project => {
                    if (project.hasOwnProperty('CustomerId__c')) {
                        if(project.hasOwnProperty('Contracts')){
                        return (
                            project.Type.toLowerCase().includes(filter.status.toLowerCase()) &&
                            project.Rating.toLowerCase().includes(filter.type.toLowerCase()) &&
                            project.CustomerId__c.includes(filter.customer) &&
                            project.Contracts[0].SPM_Members__c.includes(filter.member));
                        }else{
                            return (
                                project.Type.toLowerCase().includes(filter.status.toLowerCase()) &&
                                project.Rating.toLowerCase().includes(filter.type.toLowerCase()) &&
                                project.CustomerId__c.includes(filter.customer) );
                        }
                    } else {
                        if(project.hasOwnProperty('Contracts')){
                            return (
                                project.Type.toLowerCase().includes(filter.status.toLowerCase()) &&
                                project.Rating.toLowerCase().includes(filter.type.toLowerCase()) &&
                                project.Contracts[0].SPM_Members__c.includes(filter.member));
                            }else{
                                return (
                                    project.Type.toLowerCase().includes(filter.status.toLowerCase()) &&
                                    project.Rating.toLowerCase().includes(filter.type.toLowerCase()) );
                            }
                    }
                });
                component.set('v.projectsSelected',dataTempo);
                var projectsToDisplay = dataTempo.slice(dep, pageLenght);
                component.set('v.projectsToDisplay', projectsToDisplay);
                if (dataTempo.length === 0) {
                    this.showToast('Not found', 'error', 'No row corresponding to the search value');
                }
            } else {
                component.set('v.projectsSelected',projects);
                var projectsToDisplay = projects.slice(dep, pageLenght);
                component.set('v.projectsToDisplay', projectsToDisplay);
            }
        } else {
            var dataTemp = projects.filter(project => project.Name.toLowerCase().includes(searchKey.toLowerCase()));
            component.set('v.projectsSelected',dataTemp);
            var projectsToDisplay = dataTemp.slice(dep, pageLenght);
            component.set('v.projectsToDisplay', projectsToDisplay);
            if (dataTemp.length === 0) {
                this.showToast('Not found', 'error', 'No row corresponding to the search value');
            }
        }
    },

    getAllProjectsByProgram: function (component, pageSize, programId) {
        var action = component.get("c.getProjectsByProgram");
        action.setParams({ programId: programId })
        action.setCallback(this, function (response) {

            var state = response.getState();

            if (component.isValid() && state === "SUCCESS") {
                var projects = response.getReturnValue().data;
                component.set('v.projects', projects);
                console.log(response.getReturnValue().data);
                //console.log(response.getReturnValue().apexPages);
                component.set("v.totalSize", component.get("v.projects").length);

                component.set("v.start", 0);

                component.set("v.end", pageSize - 1);

                var numberOfProjectsToDisplay = [];
                if (component.get('v.totalSize') < pageSize) {

                    for (var i = 0; i < component.get('v.totalSize'); i++) {

                        numberOfProjectsToDisplay.push(projects[i]);

                    }
                } else {
                    for (var i = 0; i < pageSize; i++) {

                        numberOfProjectsToDisplay.push(projects[i]);

                    }
                }

                component.set('v.numberOfProjectsToDisplay', numberOfProjectsToDisplay);

                //console.log(numberOfProjectsToDisplay);

            }

        });

        $A.enqueueAction(action);
    },
    showToast: function (title, type, message) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": title,
            "type": type,
            "message": message
        });
        toastEvent.fire();
    },

    getAllCategories: function (component) {
        var action = component.get("c.getAllCategories");
        action.setCallback(this, function (response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var customResponse = response.getReturnValue();
                if (customResponse.hasError == false) {
                    let categories = customResponse.data;
                    categories.forEach((category) => {
                        category.value = category.Project_Category_Value__c;
                        category.label = category.Name;
                    });
                    categories.unshift({'value':'','label': ''});
                    component.set("v.categories", categories);
                } else {
                    console.log(customResponse.message);
                }
            }
            else {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " +
                            errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(action);
    },

    getAllStatus: function (component) {
        var action = component.get("c.getAllStatus");
        action.setCallback(this, function (response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var customResponse = response.getReturnValue();
                if (customResponse.hasError == false) {
                    let status = customResponse.data;
                    console.log(customResponse.data);
                    status.forEach((statu) => {
                        statu.value = statu.Project_Status_Value__c;
                        statu.label = statu.Name;
                    });
                    status.unshift({'value':'','label': ''});
                    component.set("v.status", status);
                } else {
                    console.log(customResponse.message);
                }
            }
            else {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " +
                            errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(action);
    },

    getAllMembers: function (component) {
        var action = component.get("c.getAllMembers");
        action.setCallback(this, function (response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var customResponse = response.getReturnValue();
                if (customResponse.hasError == false) {
                    let members = customResponse.data;
                    members.forEach((member) => {
                        member.value = member.Id;
                        member.label = member.Name;
                    });
                    members.unshift({'value':'','label': ''});
                    component.set("v.members", members);
                } else {
                    console.log(customResponse.message);
                }
            }
            else {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " +
                            errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(action);
    },



    getAllCustomer: function (component) {
        var action = component.get("c.getAllCustomers");
        action.setCallback(this, function (response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var customResponse = response.getReturnValue();
                if (customResponse.hasError == false) {
                    let customers = customResponse.data;
                    customers.forEach((customer) => {
                        customer.value = customer.Id;
                        customer.label = customer.Name;
                    });
                    customers.unshift({'value':'','label': ''});
                    component.set("v.customers", customers);
                } else {
                    console.log(customResponse.message);
                }
            }
            else {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " +
                            errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(action);
    },

    displayPrintableView : function(component){
        var datas = [];
        var projectsSelected = component.get('v.projectsSelected');
        projectsSelected.forEach(project => {
            if(project.hasOwnProperty('Contracts')){
                datas.push([project.Name,project.Rating,project.Project_Budget__c,project.Type,project.Contracts[0].SPM_Members__r.Name,project.Start_Date__c,project.End_Date__c]);
            }else{
                datas.push([project.Name,project.Rating,project.Project_Budget__c,project.Type,'',project.Start_Date__c,project.End_Date__c]);
            }
        });
        component.set('v.columns',['Name','Category','Budget','Status','Project Manager','Start Date','End Date']);
        component.set('v.printDatas',datas);
        component.set("v.print", true);
    }
})