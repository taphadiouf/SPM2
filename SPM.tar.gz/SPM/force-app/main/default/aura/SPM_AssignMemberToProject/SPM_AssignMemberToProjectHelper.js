({
    doInit : function(component) {
        var memberId = component.get('v.memberId'),
            memberHasProject = component.get('v.memberHasProject');
        memberHasProject.SPM_Members__c = memberId;
        component.set('v.memberHasProject',memberHasProject);
        var action = component.get('c.getProjectsWhereMemberIsNotMember');
        action.setParam('memberId', memberId);
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state === 'SUCCESS'){
                var returnedValue = response.getReturnValue();
                if(!returnedValue.hasError){
                    var projects = returnedValue.data;
                    for(var i=0; i<projects.length; i++){
                        projects[i].value = projects[i].Id;
                        projects[i].label = projects[i].Name;
                    }
                    console.log('projects',projects);
                    component.set('v.projects', projects);
                }
                else{
                    this.showToast('Error','Error',returnedValue.message);
                }
            }
            else if(state === 'INCOMPLETE'){
                this.showToast('Incomplete','Error','Please check for your internet connexion and refresh the page !');
            }
            else{
                this.showToast('Error','Error',response.getError());
            }
        });
        $A.enqueueAction(action);
    },
    save : function(component) {
        var memberHasProject = component.get('v.memberHasProject');
        var action = component.get('c.createMembersHasProject');
        action.setParam('memberHasProject', memberHasProject);
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state === 'SUCCESS'){
                var returnedValue = response.getReturnValue();
                if(!returnedValue.hasError){
                    var projects = component.get('v.projects'), selectedProject = null;
                    projects.forEach(project => {
                        if(project.Id === memberHasProject.AccountId){
                            selectedProject = project;
                        }
                    });
                    this.showToast('Success','Success','Member added to the project '+selectedProject.Name+' successfully');
                    var event = $A.get("e.c:SPM_AppEvents");
                    event.setParam('data', selectedProject);
                    event.setParam('action', 'addToProject');
                    event.fire();
                    component.set('v.showModal', false);
                }
                else{
                    this.showToast('Error','Error',returnedValue.message);
                }
            }
            else if(state === 'INCOMPLETE'){
                this.showToast('Incomplete','Error','Please check for your internet connexion and refresh the page !');
            }
            else{
                this.showToast('Error','Error',response.getError());
            }
        });
        $A.enqueueAction(action);
    },
    showToast: function (title, type, message) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": title,
            "type": type,
            "message": message
        });
        toastEvent.fire();
    }
})