({
    doInit : function(component,event,helper){
        var projectId = component.get('v.projectId');
        var memberId = component.get('v.memberId');
        if(projectId != ''){
            helper.getAllMemberWithoutProjectId(component , projectId);
        }if(memberId != ''){
            helper.getAllProjects(component);
        }else{
        }
      helper.getAllRoles(component);

    },
    setSelectedProject : function (component, evt) {
        var projectId = component.get('v.membersHasProject.AccountId');
        var projects = component.get('v.datas');
        projects.forEach(project => {
            if(project.Id === projectId){
                component.set('v.project', project);
            }
        });
    },
    verifyFields:function(component, event,helper){
        var isValidForm = component.find('isValideField').reduce((validSoFar,inputCmp)=>{
            inputCmp.showHelpMessageIfInvalid();
            return validSoFar && inputCmp.get('v.validity').valid;
        },true);
        if(isValidForm){
            component.set('v.isValidFields',true);
        }
            
    }
})