({
    
     deleteTask: function (component, id) {
        var action = component.get("c.deleteTask");
        var tasks = component.get('v.tasks'),task=null;
        var i= 0,position;
        tasks.forEach(tsk=> {
            if (tsk.Id === id) {
                task = tsk;
                position = i;
            }
            i++;
        });  
        console.log('id',id);
        console.log('tsk',task);
        action.setParams({ tasks: Array(task) });
        action.setCallback(this, function (response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var customResponse = response.getReturnValue();
                if (customResponse.hasError == false) {
                    activities.splice(position, 1);
                    component.set('v.tasks', tasks);
                    component.set("v.totalSize", tasks.length);
                    this.setPageAttributes(component);
                    this.datasFilter(component);
                    this.showToast('Deleted', 'Succes', 'task deleted successfully');
                                      
                }  else {
                    for (var message in customResponse.messages) {
                        console.log(message);
                    }
                }
            }
            else {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " +
                            errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(action);

    },

    editTask: function(component, id){
        var tasks = component.get('v.numberOfTasksToDisplay'), selectedTask = null;
        tasks.forEach(tsk => {
            if (tsk.Id === id) {
                selectedTask = tsk;
            }
        });
        component.set('v.isModal', true);
        component.set('v.task', selectedTask);
        component.set('v.recordId', selectedTask.Id);
    },

    showRowDetails: function (component,event,row) {
        var task = [JSON.parse(JSON.stringify(row))];
        console.log(task[0].Id)
        component.set('v.taskId',task[0].Id);
        var taskId = component.get('v.taskId');
        var recordId = component.get('v.recordId');
        
        var navEvt = $A.get("e.force:navigateToSObject");
        navEvt.setParams({
        "recordId": task[0].Id,
        "slideDevName": "related"
        });
        navEvt.fire();
        
    },

    getTasks: function(component, pageSize){
    var action = component.get("c.getAllTasks");

        action.setCallback(this, function (response) {

            var state = response.getState();

            if (component.isValid() && state === "SUCCESS") {
             var tasks = response.getReturnValue().data;
             console.log(tasks);
                 
               tasks.forEach(task=>{ 
                   if(task.hasOwnProperty('Cases')){
                          var i=0, numberActivityChecked = 0;
                            for(i = 0; i<task.Cases.length; i++){
                                if(task.Cases[i].hasOwnProperty('ActivityCompleted__c')){
                                    if(task.Cases[i].ActivityCompleted__c){
                                         numberActivityChecked += 1;
                                    }
                                }
                            
                        }
                       task.numberActivityChecked = numberActivityChecked;}
                             
                })
                component.set('v.tasks', tasks);
                component.set('v.task', tasks[0]);
                console.log(response.getReturnValue().data);
                //console.log(response.getReturnValue().apexPages);
                component.set("v.totalSize", tasks.length);
                this.setPageAttributes(component);
                this.datasFilter(component);
                component.set("v.fromOtherCmp","listTask")

            }        /*
                    var res = Description.replace(/<[^>]*>/g, '');
                    component.set('v.Description', res);*/

        });

        $A.enqueueAction(action);
    },

    
                    
     datasFilter: function (component) {
        this.setViewAttributes(component);
        var totalSize = component.get("v.totalSize");
        var numberOfRows = component.get("v.numberOfRows");
        var offset = component.get("v.offset");
        var tasks = component.get("v.tasks");
        var numberOfTasksToDisplay = Array();
        var limit = offset + numberOfRows;
        for (var i = offset; i < limit && i < totalSize; i++) {
            numberOfTasksToDisplay.push(tasks[i]);
        }
        component.set("v.numberOfTasksToDisplay", numberOfTasksToDisplay);
        this.hideSpinner(component);
    },
    /**
     * set the variables values for the list
     * @param {*} component an instance of the component
     */
    setViewAttributes: function (component) {
        var numberOfRows = component.get("v.numberOfRows");
        var currentPageNumber = component.get("v.currentPageNumber");
        var offset = (currentPageNumber - 1) * numberOfRows;
        component.set("v.offset", offset);
    },
    setPageAttributes: function (component) {
        var numberOfRows = component.get("v.pageSize");
        var totalSize = component.get("v.totalSize");
        var numberOfPages = Math.ceil(totalSize / numberOfRows);
        var pages = Array();
        for (var i = 1; i <= numberOfPages; i++) {
            pages.push(i);
        }
        component.set("v.pages", pages);
        component.set("v.numberOfPages", numberOfPages);
    },
    // this function automatic call by aura:waiting event  
    showSpinner: function (component) {
        // make Spinner attribute true for display loading spinner 
        component.set("v.loading", true);
    },

    // this function automatic call by aura:doneWaiting event 
    hideSpinner: function (component) {
        // make Spinner attribute to false for hide loading spinner    
        component.set("v.loading", false);
    },
    /**
     * display a toast
     * @param {*} title the title of the toast
     * @param {*} message the message to display in the toast
     */
    showToast : function(title, type, message) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": title,
            "type": type,
            "message": message
        });
        toastEvent.fire();
    },
                    
     search : function(component, value) {
        var totalSize = component.get("v.totalSize");
        var tasks = component.get("v.tasks");
        var numberOfTasksToDisplay = Array();
        for(var i = 0; i < totalSize; i++){
            //look if the members name on the index i includes the searched value and if it's true, add the course on the list to diaplay
            if(tasks[i].Name.toLowerCase().includes(value.toLowerCase())){
                numberOfTasksToDisplay.push(tasks[i]);
            }
        }
        if(numberOfTasksToDisplay.length === 0){
            this.showToast('Not found','error', 'No row corresponding to the search value');
        }
        component.set("v.numberOfTasksToDisplay", numberOfTasksToDisplay);
         this.hideSpinner(component);
     },
                      
       showRowDetails: function (component, event, taskId) {
        var navEvt = $A.get("e.force:navigateToSObject");
        navEvt.setParams({
            "recordId": taskId,
            "slideDevName": "related"
        });
        navEvt.fire();

    },
                    
     getAllMembers: function (component) {
        var action = component.get("c.getAllMembers");
        action.setCallback(this, function (response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var customResponse = response.getReturnValue();
                if (customResponse.hasError == false) {
                    let members = customResponse.data;
                    members.forEach((member) => {
                        member.value = member.Id;
                        member.label = member.Name;
                    });
                    component.set("v.members", members);
                } else {
                    console.log(customResponse.message);
                }
            }
            else {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " +
                            errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(action);
    },

                        
   allProject: function (component, pageSize) {
        var action = component.get("c.getAllProjects");
        action.setCallback(this, function (response) {
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                var projects = response.getReturnValue().data;
                component.set('v.projects', projects);
                //component.set('v.membersHasProject', response.getReturnValue().membersHasProject);
                component.set('v.createdById', response.getReturnValue().createdById);
                console.log(response.getReturnValue().data);
                //.log('membersHasProject ' + response.getReturnValue().membersHasProject);
                component.set("v.totalSize", component.get("v.projects").length);
                var numberOfPages = component.get("v.projects").length / component.get("v.pageSize");
                console.log('--------nombre de pages------------- ' + numberOfPages);
                var pages = [];
                for (var i = 0; i < numberOfPages; i++) {
                    if (i === 0) {
                        pages[i] = i;
                    } else {
                        pages[i] = Number(pages[i - 1]) + Number(component.get("v.pageSize"));
                    }
                }
                component.set("v.pages", pages);
                component.set("v.numberOfPages", pages[i - 1]);
                this.helperFunction(component, 0, component.get("v.pageSize"));
            }

        });

        $A.enqueueAction(action);
        } ,

       showRowDetailsProject: function (component, event, AccountId) {
        var navEvt = $A.get("e.force:navigateToSObject");
        navEvt.setParams({
            "recordId": AccountId,
            "slideDevName": "related"
        });
        navEvt.fire();

    },
       /*                 
       showDetailsMember: function (component, event, Link__c) {
        var navEvt = $A.get("e.force:navigateToSObject");
        navEvt.setParams({
            "recordId": Link__c,
            "slideDevName": "related"
        });
        navEvt.fire();

    },*/
})