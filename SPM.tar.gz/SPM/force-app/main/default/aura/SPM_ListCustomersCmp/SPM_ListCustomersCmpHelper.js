({

    deleteCustomer: function (component) {
        var customers = component.get('v.customers'), selectedCustomer = null;
        var id = component.get('v.customerId');
        var i = 0, position;
        customers.forEach(customer => {
            if (customer.Id === id) {
                selectedCustomer = customer;
                position = i;
            }
            i++;
        });
        console.log(id);
        var action = component.get("c.deleteCustomer");
        action.setParams({ customers: [selectedCustomer] });
        action.setCallback(this, function (response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var customResponse = response.getReturnValue();
                if (customResponse.hasError == false) {
                    customers.splice(position, 1);
                    component.set('v.showConfirmation',false);
                    component.set('v.customers', customers);
                    component.set('v.customerId', '');
                    component.set("v.totalSize", customers.length);
                    this.setPageAttributes(component);
                    this.datasFilter(component);
                    this.showToast('Deleted', 'Success', 'Customer deleted successfully');
                } else {
                    var messages = '';
                    for (var message in customResponse.messages) {
                        messages += message + '\n';
                        console.log(message);
                    }
                    this.showToast('Error', 'Error', messages);
                }
            }
            else {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " +
                            errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(action);
    },
    everyMinute: function (component) {
        var that = this;
        window.setTimeout(
            $A.getCallback(function () {
                var updated = component.get('v.updated');
                updated = updated + 1;
                component.set('v.updated', updated);
                var upadateHours = Math.floor(component.get('v.updated') / 60);
                component.set('v.updatedHours', upadateHours);
                that.everyMinute(component);
            }), 60000
        );

    },
    
    editCustomer: function (component, id) {
        var customers = component.get('v.customersTodisplay'), selectedCustomer = null;
        customers.forEach(customer => {
            if (customer.Id === id) {
                selectedCustomer = customer;
            }
        });
        component.set('v.isModal', true);
        component.set('v.customer', selectedCustomer);
        component.set('v.recordId', selectedCustomer.Id);
    },
    getCustomers: function (component) {
        var action = null;
        var pageSize = component.get("v.pageSize");

        var action = component.get("c.getAllCustomers");

        action.setCallback(this, function (response) {

            var state = response.getState();

            if (component.isValid() && state === "SUCCESS") {
                var customers = response.getReturnValue().data;
                console.log('#L customers', (JSON.stringify(customers)));

                component.set('v.customers', customers);
                component.set('v.customersToPrint', customers);
                console.log(customers.length);
                //console.log(response.getReturnValue().apexPages);
                component.set("v.totalSize", component.get("v.customers").length);

                this.setPageAttributes(component);
                this.datasFilter(component);

            } else {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        this.showToast('Error', 'error', errors[0].message);
                        console.log("Error message: " +
                            errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }

        });

        $A.enqueueAction(action);
    },
    showRowDetails: function (component, id) {
        var customers = component.get('v.customersTodisplay'), selecteCustomer = null;
        customers.forEach(customer => {
            if (customer.Id === id) {
                selecteCustomer = customer;
            }
        });
        component.set('v.recordId', id);
        var recordId = component.get('v.recordId');
        var pageReference = {
            type: 'standard__component',
            attributes: {
                componentName: 'c__SPM_ShowCustomerDetailsCmp',
            },
            state: {
                "c__Id": recordId,
                "c__customer": selecteCustomer
            }
        };
        component.set("v.pageReference", pageReference);
        var navService = component.find("navService");
        var pageReference = component.get("v.pageReference");
        navService.navigate(pageReference);
        //var evt = $A.get("e.c:SPM_ShowDetailCustomerEvt");
       // evt.fire();
    },/**
    * search the corresping course's name to the search value on the the list of all members and display it the table
    * @param {*} component an instance of the component
    * @param {*} value the searched value
    */
    search: function (component, value) {
        var totalSize = component.get("v.totalSize");
        var customers = component.get("v.customers");
        var customersTodisplay = Array();
        for (var i = 0; i < totalSize; i++) {
            //look if the member's name on the index i includes the searched value and if it's true, add the course on the list to diaplay
            if (customers[i].Name.toLowerCase().includes(value.toLowerCase())) {
                customersTodisplay.push(customers[i]);
            }
        }
        if (customersTodisplay.length === 0) {
            this.showToast('Not found', 'error', 'No row corresponding to the search value');
        }
        component.set("v.customersTodisplay", customersTodisplay);
        component.set("v.customersToPrint", customersTodisplay);
        component.set("v.numberItems", customersTodisplay.length);
        this.hideSpinner(component);
    },
    /**
     * filter datas to display in the table
     * @param {*} component an instance of the component
     */
    datasFilter: function (component) {
        this.setViewAttributes(component);
        var totalSize = component.get("v.totalSize");
        var numberOfRows = component.get("v.numberOfRows");
        var offset = component.get("v.offset");
        var customers = null;
        var showFilter = component.get("v.showFilter");
        if (!showFilter) {
            customers = component.get("v.customers");
        }
        else {
            customers = component.get("v.filteredCustomers");
        }
        var customersTodisplay = Array();
        var limit = offset + numberOfRows;
        for (var i = offset; i < limit && i < totalSize; i++) {
            customersTodisplay.push(customers[i]);
        }
        component.set("v.customersTodisplay", customersTodisplay);
        component.set("v.numberItems", customersTodisplay.length);
        this.hideSpinner(component);
    },
    /**
     * set the variables values for the list
     * @param {*} component an instance of the component
     */
    setViewAttributes: function (component) {
        var numberOfRows = component.get("v.numberOfRows");
        var currentPageNumber = component.get("v.currentPageNumber");
        var offset = (currentPageNumber - 1) * numberOfRows;
        component.set("v.offset", offset);
    },
    setPageAttributes: function (component) {
        var numberOfRows = component.get("v.numberOfRows");
        var totalSize = component.get("v.totalSize");
        var numberOfPages = Math.ceil(totalSize / numberOfRows);
        var pages = Array();
        for (var i = 1; i <= numberOfPages; i++) {
            pages.push(i);
        }
        component.set("v.pages", pages);
        component.set("v.numberOfPages", numberOfPages);
    },
    // this function automatic call by aura:waiting event  
    showSpinner: function (component) {
        // make Spinner attribute true for display loading spinner 
        component.set("v.loading", true);
    },

    // this function automatic call by aura:doneWaiting event 
    hideSpinner: function (component) {
        // make Spinner attribute to false for hide loading spinner    
        component.set("v.loading", false);
    },
    /**
     * display a toast
     * @param {*} title the title of the toast
     * @param {*} type the type of the toast
     * @param {*} message the message to display in the toast
     */
    showToast: function (title, type, message) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": title,
            "type": type,
            "message": message
        });
        toastEvent.fire();
    },
    displayPrintableView : function(component){
        var datas = [];
        var customers = component.get('v.customersToPrint');
        customers.forEach(customer => {
            datas.push([customer.MailingCity,customer.MailingState,customer.MailingCountry,customer.Title]);
        });
        component.set('v.columns',['NamINvoice Addresse','City','Country Unit','Contact']);
        component.set('v.printDatas',datas);
        component.set("v.print", true);
    }

})