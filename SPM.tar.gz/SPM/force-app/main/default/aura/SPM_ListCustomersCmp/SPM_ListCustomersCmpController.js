({

    doInit: function (component, event, helper) {
        helper.getCustomers(component);
        helper.everyMinute(component);
    },
    handleRowAction: function (component, event, helper) {
        var value = event.getParam('value'),
            action = value.split('|')[0],
            id = value.split('|')[1];
        switch (action) {
            case 'delete':
                component.set('v.showConfirmation',true);
                component.set('v.customerId',id);
                break;
            case 'edit':
                helper.editCustomer(component, id);
                break;
        }
    },
    showDetails: function (component, event, helper) {
        event.preventDefault();
        var id = event.srcElement.name;
        var navEvt = $A.get("e.force:navigateToSObject");
        navEvt.setParams({
            "recordId": id,
            "slideDevName": "view"
        });
        navEvt.fire();
        //helper.showRowDetails(component, id);
    },
    openModalAddCustomer: function (component, event, helper) {
        component.set('v.recordId', '');
        component.set('v.isModal', true);
        //console.log('userId ' + component.get('v.userId'))
    },
    addCustomerTolist: function (component, event, helper) {
        var customer = event.getParam('customer');
        var customers = component.get('v.customers');
        console.log(customer);
        customers.unshift(customer);
        component.set('v.customers', customers);
        component.set('v.totalSize', customers.length);
        helper.datasFilter(component);
    },
    
    //the called method when the search value is changed
    search: function (component, event, helper) {
        var searchValue = component.get("v.searchValue");
        if (searchValue === "") {
            helper.datasFilter(component);
        }
        else {
            helper.search(component, searchValue);
        }
    },
    selectedPage: function (component, event, helper) {
        helper.showSpinner(component);
        var selectedPageNumber = Number(event.getSource().get('v.name'));
        component.set("v.currentPageNumber", selectedPageNumber);
        helper.datasFilter(component);
    },
    nextPage: function (component, event, helper) {
        helper.showSpinner(component);
        var currentPageNumber = component.get("v.currentPageNumber");
        component.set("v.currentPageNumber", currentPageNumber + 1);
        helper.datasFilter(component);
    },
    previousPage: function (component, event, helper) {
        helper.showSpinner(component);
        var currentPageNumber = component.get("v.currentPageNumber");
        component.set("v.currentPageNumber", currentPageNumber - 1);
        helper.datasFilter(component);
    },
    refreshView: function (component, event, helper) {
        helper.showSpinner(component);
        helper.datasFilter(component);
    },
    
    delete :function(component, event, helper){
        helper.deleteCustomer(component);
    },
    cancel : function(component, event, helper){
        component.set('v.showConfirmation',false);
    },
    printPage: function (component, event, helper) {
        helper.displayPrintableView(component);
    },
    uploadCsv: function (component, event, helper) {
        component.set('v.isImportProject', true);
    },

})