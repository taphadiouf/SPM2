({
    doInit: function (component, event, helper) {
        helper.getCustomer(component);
    },
    /*showConfirmation : function(component, event, helper){
        component.set('v.showConfirmation',true);
    },
    delete :function(component, event, helper){
        helper.deleteCustomer(component);
    },*/
    cancel : function(component, event, helper){
        component.set('v.showConfirmation',false);
    },
    editCustomer : function(component, event, helper){
        component.set('v.isModal',true);
        component.set('v.recordId',component.get('v.recordId'));
    }, 
    createProjectForthisCustom : function(component, event, helper){
        component.set('v.isModalProject',true); 
        var customer = component.get('v.customer');
        var id  = customer.Id;
        component.set('v.customerId',id); 
    },
})