({
    createCSVObject: function (cmp, csv) {
        var action = cmp.get('c.getCSVObject');
        action.setParams({
            csv_str: csv
        });
        action.setCallback(this, function (response) {
            var state = response.getState();
            if (state == "SUCCESS") {
                cmp.set("v.csvObject", response.getReturnValue().lines);
                cmp.set("v.csvObjectError", response.getReturnValue().lines_error);
            }
        });
        $A.enqueueAction(action);
    },

    convertArrayOfObjectsToCSV: function (component, objectRecords) {
        var csvStringResult, counter, columnDivider, lineDivider;
        if (objectRecords.lines == null || !objectRecords.lines.length) {
            return null;
        }
        columnDivider = ',';
        lineDivider = '\n';
        var headers = [];
        for (var j = 0; j < objectRecords.headers.length; j++) {
            headers[j] = objectRecords.headers[j].column_name;
        }
        //headers = ['FirstName','LastName','Department','MobilePhone','Id','FirstName','LastName','Department','MobilePhone','Id' ];

        csvStringResult = '';
        csvStringResult += headers.join(columnDivider);
        csvStringResult += lineDivider;

        for (var i = 0; i < objectRecords.lines.length; i++) {
            counter = 0;
            for (var j = 0; j < headers.length; j++) {
                if (counter > 0) {
                    csvStringResult += columnDivider;
                }
                if (objectRecords.lines[i][j] != undefined) {
                    csvStringResult += '"' + objectRecords.lines[i][j] + '"';
                }
                counter++;
            }
            csvStringResult += lineDivider;
        }
        return csvStringResult;
    },
})