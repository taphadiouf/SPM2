({

    doInit: function (component, event, helper) {
        var pageSize = component.get("v.pageSize");
        var projectId = component.get("v.recordId");

        if (projectId === '') {
            helper.getAllMembersHasProjects(component, pageSize);
        } else {
            helper.getAllMemberByProjectId(component, pageSize, projectId);
        }

    },

    handleRowAction: function (component, event, helper) {
        var value = event.getParam('value'),
            action = value.split(' ')[0],
            row = value.split(' ')[1];
            console.log('row---- '+row)
        switch (action) {
            case 'delete':{
                var confirmDelete = component.get('v.confirmDelete');
                confirmDelete.confirm = true;
                confirmDelete.projectDeleted = row;
                component.set('v.confirmDelete',confirmDelete)
            }
                break;
            case 'edit':
                helper.editMembersHasProject(component, row);
            default:
        }
    },
    openModalAddMember: function (component, event, helper) {
        component.set('v.isModal', true);
    },
    updatelist: function (component, event, helper) {
        var member = event.getParam('memberHasProject');
        var type = event.getParam('type');
        var membersHasProject = component.get('v.membersHasProject');
        if(type === 'update'){
            var index = membersHasProject.findIndex((memberHasProject) => memberHasProject.Id === member.Id);
            if(index >=0){
                membersHasProject[index]=member;
            }
        }else{
            console.log('le nouveau membre' +member);
            membersHasProject.unshift(member);
        }
       component.set('v.membersHasProject', membersHasProject);
    }, 

    showDetails: function (component, event, helper) {
        var target = event.currentTarget;
        var memberId = target.getAttribute("data-selected-Index");
        helper.showRowDetails(memberId);
    },
    delete :function(component, event, helper){
        helper.deleteMemberHasProject(component, (component.get('v.confirmDelete')).projectDeleted);
        var confirmDelete = component.get('v.confirmDelete');
                confirmDelete.confirm = false;
                component.set('v.confirmDelete',confirmDelete);
    },
    cancel : function(component, event, helper){
        var confirmDelete = component.get('v.confirmDelete');
                confirmDelete.confirm = false;
                component.set('v.confirmDelete',confirmDelete);
    },
})