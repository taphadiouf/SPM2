({
    doInit: function (component, event, helper) {
        helper.getMembers(component);
        helper.everyMinute(component);
    },
    handleRowAction: function (component, event, helper) {
        var value = event.getParam('value'),
            action = value.split('|')[0],
            id = value.split('|')[1];
        switch (action) {
            case 'delete':
                component.set('v.showConfirmation',true);
                component.set('v.memberId',id);
                break;
            case 'edit':
                helper.editMember(component, id);
                break;
        }
    },
    showDetails: function (component, event, helper) {
        event.preventDefault();
        var id = event.srcElement.name;
        var navEvt = $A.get("e.force:navigateToSObject");
        navEvt.setParams({
            "recordId": id,
            "slideDevName": "view"
        });
        navEvt.fire();
        //helper.showRowDetails(component, id);
    },
    openModalAddMember: function (component, event, helper) {
        component.set('v.recordId', '');
        component.set('v.isModal', true);
        console.log('userId ' + component.get('v.userId'))
    },
    addMemberTolist: function (component, event, helper) {
        var member = event.getParam('member');
        var members = component.get('v.members');
        console.log(member);
        members.unshift(member);
        component.set('v.members', members);
        component.set('v.totalSize', members.length);
        helper.datasFilter(component);
    },
    applyFilter: function (component, event, helper) {
        var projectId = event.getParam("value"),
            membersHasProject = component.get('v.membersHasProject'),
            members = component.get('v.members'), filteredMembers = Array();
        if (projectId === 'all') {
            filteredMembers = members;
        }
        else {
            var projectMembers = membersHasProject.filter(memberHasProject =>
                memberHasProject.AccountId.includes(projectId)
            );
            projectMembers.forEach(memberHasProject => {
                members.forEach(member => {
                    if (member.Id === memberHasProject.SPM_Members__c) {
                        filteredMembers.push(member);
                    }
                });
            });
        }
        component.set('v.totalSize', filteredMembers.length);
        component.set('v.filteredMembers', filteredMembers);
        component.set('v.membersToPrint', filteredMembers);
        component.set('v.currentPageNumber', 1);
        helper.setPageAttributes(component);
        helper.datasFilter(component);
    },
    //the called method when the search value is changed
    search: function (component, event, helper) {
        var searchValue = component.get("v.searchValue");
        if (searchValue === "") {
            helper.datasFilter(component);
        }
        else {
            helper.search(component, searchValue);
        }
    },
    selectedPage: function (component, event, helper) {
        helper.showSpinner(component);
        var selectedPageNumber = Number(event.getSource().get('v.name'));
        component.set("v.currentPageNumber", selectedPageNumber);
        helper.datasFilter(component);
    },
    nextPage: function (component, event, helper) {
        helper.showSpinner(component);
        var currentPageNumber = component.get("v.currentPageNumber");
        component.set("v.currentPageNumber", currentPageNumber + 1);
        helper.datasFilter(component);
    },
    previousPage: function (component, event, helper) {
        helper.showSpinner(component);
        var currentPageNumber = component.get("v.currentPageNumber");
        component.set("v.currentPageNumber", currentPageNumber - 1);
        helper.datasFilter(component);
    },
    refreshView: function (component, event, helper) {
        helper.showSpinner(component);
        helper.datasFilter(component);
    },
    filter: function (component, event, helper) {
        var showFilter = component.get('v.showFilter');
        if (showFilter === true) {
            var members = component.get('v.members');
            component.set('v.totalSize', members.length);
            component.set('v.showFilter', false);
            helper.setPageAttributes(component);
            helper.datasFilter(component);
        }
        else {
            component.set('v.showFilter', true);
        }
    },
    delete :function(component, event, helper){
        helper.deleteMember(component);
    },
    cancel : function(component, event, helper){
        component.set('v.showConfirmation',false);
    },
    printPage: function (component, event, helper) {
        helper.displayPrintableView(component);
    }

})