({

    deleteMember: function (component) {
        var members = component.get('v.members'), selectedMember = null;
        var id = component.get('v.memberId');
        var i = 0, position;
        members.forEach(member => {
            if (member.Id === id) {
                selectedMember = member;
                position = i;
            }
            i++;
        });
        console.log(id);
        var action = component.get("c.deleteMembers");
        action.setParams({ members: [selectedMember] });
        action.setCallback(this, function (response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var customResponse = response.getReturnValue();
                if (customResponse.hasError == false) {
                    members.splice(position, 1);
                    component.set('v.members', members);
                    component.set('v.memberId', '');
                    component.set("v.totalSize", members.length);
                    this.setPageAttributes(component);
                    this.datasFilter(component);
                    this.showToast('Deleted', 'Success', 'Member deleted successfully');
                } else {
                    var messages = '';
                    for (var message in customResponse.messages) {
                        messages += message + '\n';
                        console.log(message);
                    }
                    this.showToast('Error', 'Error', messages);
                }
            }
            else {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " +
                            errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(action);
    },
    everyMinute: function (component) {
        var that = this;
        window.setTimeout(
            $A.getCallback(function () {
                var updated = component.get('v.updated');
                updated = updated + 1;
                component.set('v.updated', updated);
                var upadateHours = Math.floor(component.get('v.updated') / 60);
                component.set('v.updatedHours', upadateHours);
                that.everyMinute(component);
            }), 60000
        );

    },
    
    editMember: function (component, id) {
        var members = component.get('v.membersTodisplay'), selectedMember = null;
        members.forEach(member => {
            if (member.Id === id) {
                selectedMember = member;
            }
        });
        component.set('v.isModal', true);
        component.set('v.member', selectedMember);
        component.set('v.recordId', selectedMember.Id);
    },
    getMembers: function (component) {
        var orgUnitId = component.get('v.orgUnitId'),
            userId = component.get('v.userId'),
            action = null;
        if (userId != '') {
            action = component.get("c.getAllMembersByUserId");
            action.setParams({ userId: userId });
        }
        else if (orgUnitId != '') {
            action = component.get("c.getAllMembersByOrgUnitId");
            action.setParams({ orgUnitId: orgUnitId });
        }
        else {
            action = component.get("c.getAllMembers");
        }
        action.setCallback(this, function (response) {
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                var members = response.getReturnValue().data;
                if (userId === '' && orgUnitId === '') {
                    var membersHasProject = response.getReturnValue().membersHasProject;
                    var projectsHasMembers = Array(), found;
                    projectsHasMembers.push({
                        label: 'All',
                        value: 'all'
                    });
                    membersHasProject.forEach(memberHasProject => {
                        found = false;
                        projectsHasMembers.forEach(project => {
                            if (project.value === memberHasProject.AccountId) {
                                found = true;
                            }
                        });
                        if (!found) {
                            projectsHasMembers.push({
                                label: memberHasProject.Account.Name,
                                value: memberHasProject.AccountId
                            });
                        }
                    });
                    component.set('v.membersHasProject', membersHasProject);
                    component.set('v.projectsHasMembers', projectsHasMembers);
                }
                component.set('v.members', members);
                component.set('v.membersToPrint', members);
                component.set("v.totalSize", members.length);
                this.setPageAttributes(component);
                this.datasFilter(component);
            } else {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        this.showToast('Error', 'error', errors[0].message);
                        console.log("Error message: " +
                            errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(action);
    },
    showRowDetails: function (component, id) {
        var members = component.get('v.membersTodisplay'), selectedMember = null;
        members.forEach(member => {
            if (member.Id === id) {
                selectedMember = member;
            }
        });
        component.set('v.recordId', id);
        var recordId = component.get('v.recordId');
        var pageReference = {
            type: 'standard__component',
            attributes: {
                componentName: 'c__SPM_ShowMemberDetailsCmp',
            },
            state: {
                "c__Id": recordId,
                "c__userId": selectedMember.UserId__c,
                "c__member": selectedMember
            }
        };
        component.set("v.pageReference", pageReference);
        var navService = component.find("navService");
        var pageReference = component.get("v.pageReference");
        navService.navigate(pageReference);
        var evt = $A.get("e.c:SPM_ShowDetailMemberEvt");
        evt.fire();
    },/**
    * search the corresping course's name to the search value on the the list of all members and display it the table
    * @param {*} component an instance of the component
    * @param {*} value the searched value
    */
    search: function (component, value) {
        var totalSize = component.get("v.totalSize");
        var members = component.get("v.members");
        var membersTodisplay = Array();
        for (var i = 0; i < totalSize; i++) {
            //look if the member's name on the index i includes the searched value and if it's true, add the course on the list to diaplay
            if (members[i].Name.toLowerCase().includes(value.toLowerCase())) {
                membersTodisplay.push(members[i]);
            }
        }
        if (membersTodisplay.length === 0) {
            this.showToast('Not found', 'error', 'No row corresponding to the search value');
        }
        component.set("v.membersTodisplay", membersTodisplay);
        component.set("v.membersToPrint", membersTodisplay);
        component.set("v.numberItems", membersTodisplay.length);
        this.hideSpinner(component);
    },
    /**
     * filter datas to display in the table
     * @param {*} component an instance of the component
     */
    datasFilter: function (component) {
        this.setViewAttributes(component);
        var totalSize = component.get("v.totalSize");
        var numberOfRows = component.get("v.numberOfRows");
        var offset = component.get("v.offset");
        var members = null;
        var showFilter = component.get("v.showFilter");
        if (!showFilter) {
            members = component.get("v.members");
        }
        else {
            members = component.get("v.filteredMembers");
        }
        var membersTodisplay = Array();
        var limit = offset + numberOfRows;
        for (var i = offset; i < limit && i < totalSize; i++) {
            membersTodisplay.push(members[i]);
        }
        component.set("v.membersTodisplay", membersTodisplay);
        component.set("v.numberItems", membersTodisplay.length);
        this.hideSpinner(component);
    },
    /**
     * set the variables values for the list
     * @param {*} component an instance of the component
     */
    setViewAttributes: function (component) {
        var numberOfRows = component.get("v.numberOfRows");
        var currentPageNumber = component.get("v.currentPageNumber");
        var offset = (currentPageNumber - 1) * numberOfRows;
        component.set("v.offset", offset);
    },
    setPageAttributes: function (component) {
        var numberOfRows = component.get("v.numberOfRows");
        var totalSize = component.get("v.totalSize");
        var numberOfPages = Math.ceil(totalSize / numberOfRows);
        var pages = Array();
        for (var i = 1; i <= numberOfPages; i++) {
            pages.push(i);
        }
        component.set("v.pages", pages);
        component.set("v.numberOfPages", numberOfPages);
    },
    // this function automatic call by aura:waiting event  
    showSpinner: function (component) {
        // make Spinner attribute true for display loading spinner 
        component.set("v.loading", true);
    },

    // this function automatic call by aura:doneWaiting event 
    hideSpinner: function (component) {
        // make Spinner attribute to false for hide loading spinner    
        component.set("v.loading", false);
    },
    /**
     * display a toast
     * @param {*} title the title of the toast
     * @param {*} type the type of the toast
     * @param {*} message the message to display in the toast
     */
    showToast: function (title, type, message) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": title,
            "type": type,
            "message": message
        });
        toastEvent.fire();
    },
    displayPrintableView : function(component){
        var datas = [];
        var absences = component.get('v.absencesToPrint');
        absences.forEach(absence => {
            datas.push([absence.Contact.Name,absence.SuppliedPhone,absence.Absence_Status__c,absence.CreatedDate,absence.EndDate__c]);
        });
        component.set('v.columns',['Member','Type','Status','Start Date','End Date']);
        component.set('v.printDatas',datas);
        component.set("v.print", true);
    },displayPrintableView : function(component){
        var datas = [];
        var members = component.get('v.membersToPrint');
        members.forEach(member => {
            datas.push([member.Name,member.LeadSource,member.Level__c,member.organisation_Unit__r.Name]);
        });
        component.set('v.columns',['Name','Gender','Contract Type','Organisation Unit']);
        component.set('v.printDatas',datas);
        component.set("v.print", true);
    }
})