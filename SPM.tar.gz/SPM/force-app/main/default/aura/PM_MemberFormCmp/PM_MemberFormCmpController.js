({
	myAction : function(component, event, helper) {
		
	},
    doInit : function(component,event,helper){
        //find all users
        helper.getAllUsers(component);
    }
})