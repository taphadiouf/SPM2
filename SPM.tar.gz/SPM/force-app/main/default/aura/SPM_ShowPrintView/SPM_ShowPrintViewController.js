({
    print: function (component, event, helper) {
        window.print();
    },
    closeWindow: function (component, event, helper) {
        component.set("v.showPrintableView", false);
    }
})