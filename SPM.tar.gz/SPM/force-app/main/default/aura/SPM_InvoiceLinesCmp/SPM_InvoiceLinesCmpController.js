({

   /* doInit: function(component, event, helper){
        var listInv = component.get('v.invoiceLinesToDisplay');
        console.log('invoiceLinesToDisplay ## ', listInv);
        if(listInv !== null){
            component.set('v.isEmpty', true);
        }
    },*/

    openModalAddExpenses: function (component, event, helper) {
        component.set('v.openModal', true);
    }
})