({
    doInit: function (component, event, helper) {
        helper.getMember(component);
    },
    togglePicture: function (component, event, helper) {
        var picture = document.getElementById('picture');
        if(picture.style.display === "none"){
            picture.style.display = "block";
            picture.style.top = (event.y+15)+'px';
            picture.style.left = (event.x-30)+'px';
        }
        else{
            var picture = document.getElementById('picture');
            picture.style.display = "none"
        }
    },
    showConfirmation : function(component, event, helper){
        component.set('v.showConfirmation',true);
    },
    assignTask : function(component, event, helper){
        component.set('v.assignTask',true);
    },
    delete :function(component, event, helper){
        helper.deleteMember(component);
    },
    cancel : function(component, event, helper){
        component.set('v.showConfirmation',false);
    },
    editMember : function(component, event, helper){
        component.set('v.isModal',true);
    },
    addToProject : function(component, event, helper){
        component.set('v.addToProject',true);
    },
})