({
    getMemberProjects: function (component) {
        console.log(' ############ running helper ');
        var action = component.get("c.getProjectsAndNotAssignedTaskByMemberHasProject");
        action.setParams({ memberId: component.get('v.memberId') });
        action.setCallback(this, function (response) {

            var state = response.getState();
            if (state === "SUCCESS") {
                var customResponse = response.getReturnValue();
                if (customResponse.hasError == false) {
                    let projects = [];
                    customResponse.data.forEach(project => {
                        project.label = project.Name;
                        project.value = project.Id;
                        project.memberHasProjectId = project.Contracts[0].Id;
                        projects.push(project);
                    });
                    component.set("v.projects", projects);
                } else {
                    console.log(customResponse.message);
                }
            }
            else {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " +
                            errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(action);
    },


    getAllMemberByProjectId: function (component) {
        var action = component.get("c.getAllMemberByProjectId");
        action.setParams({ projectId: component.get('v.projectId') })

        action.setCallback(this, function (response) {

            var state = response.getState();

            if (component.isValid() && state === "SUCCESS") {
                console.log('ce qui est retourne ' + response.getReturnValue().data);
                var membersHasProject = response.getReturnValue().data;
                membersHasProject.forEach(memberHasProject => {

                    memberHasProject.label = memberHasProject.SPM_Members__r.Name;
                    memberHasProject.value = memberHasProject.Id;

                });
                component.set('v.membersHasProject', membersHasProject);
                console.log(response.getReturnValue().data);

            }

        });

        $A.enqueueAction(action);
    }
})